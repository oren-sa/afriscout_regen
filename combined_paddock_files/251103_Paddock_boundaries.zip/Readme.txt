2025-10-29
Data provided by Aramde on 2025-10-27 containing final polygons for most RGUs and Paddocks. 6 are still missing- awaiting Afriscout Finalization of boundaries.